# -*- coding: utf-8 -*-
"""
    pygments.styles.roperdot
    ~~~~~~~~~~~~~~~~~~~~~~

    roperdot Pygments style
"""

from pygments.style import Style
from pygments.token import Keyword, Name, Comment, String, Error, Text, \
     Number, Operator, Generic, Whitespace, Punctuation, Other, Literal

import os

class RoperdotStyle(Style):

    def envColor(colorName, default):
        color = os.environ.get(colorName)
        if color:
            return '#' + color
        return default

    GREEN = envColor("COLOR_GREEN_RGB", "#7a8431")
    YELLOW = envColor("COLOR_YELLOW_RGB", "#d4804d")
    BRCYAN = envColor("COLOR_BRCYAN_RGB", "#79b2a8")
    BRBLUE = envColor("COLOR_BRBLUE_RGB", "#6f90b0")
    BRGREEN = envColor("COLOR_BRGREEN_RGB", "#a6b255")
    BRMAGENTA = envColor("COLOR_BRMAGENTA_RGB", "#a27fad")
    BRYELLOW = envColor("COLOR_BRYELLOW_RGB", "#ebbb61")

    styles = {
        # No corresponding class for the following:
        Text:                      "", # class:  ''
        Whitespace:                "",        # class: 'w'
        Error:                     "", # class: 'err'
        Other:                     "",        # class 'x'

        Comment:                   GREEN, # class: 'c'
        Comment.Multiline:         "",        # class: 'cm'
        Comment.Preproc:           "",        # class: 'cp'
        Comment.Single:            "",        # class: 'c1'
        Comment.Special:           "",        # class: 'cs'

        Keyword:                   BRMAGENTA, # class: 'k'
        Keyword.Constant:          "",        # class: 'kc'
        Keyword.Declaration:       BRBLUE,        # class: 'kd'
        Keyword.Namespace:         "", # class: 'kn'
        Keyword.Pseudo:            "",        # class: 'kp'
        Keyword.Reserved:          BRBLUE,        # class: 'kr'
        Keyword.Type:              BRGREEN,        # class: 'kt'

        Operator:                  "", # class: 'o'
        Operator.Word:             "",        # class: 'ow' - like keywords

        Punctuation:               "", # class: 'p'

        Name:                      BRCYAN, # class: 'n'
        Name.Attribute:            BRCYAN, # class: 'na' - to be revised
        Name.Builtin:              BRGREEN,        # class: 'nb'
        Name.Builtin.Pseudo:       "",        # class: 'bp'
        Name.Class:                "", # class: 'nc' - to be revised
        Name.Constant:             "", # class: 'no' - to be revised
        Name.Decorator:            "", # class: 'nd' - to be revised
        Name.Entity:               "",        # class: 'ni'
        Name.Exception:            "", # class: 'ne'
        Name.Function:             "", # class: 'nf'
        Name.Property:             "",        # class: 'py'
        Name.Label:                "",        # class: 'nl'
        Name.Namespace:            "",        # class: 'nn' - to be revised
        Name.Other:                "", # class: 'nx'
        Name.Tag:                  BRBLUE, # class: 'nt' - like a keyword
        Name.Variable:             "",        # class: 'nv' - to be revised
        Name.Variable.Class:       "",        # class: 'vc' - to be revised
        Name.Variable.Global:      "",        # class: 'vg' - to be revised
        Name.Variable.Instance:    "",        # class: 'vi' - to be revised

        Number:                    "", # class: 'm'
        Number.Float:              "",        # class: 'mf'
        Number.Hex:                "",        # class: 'mh'
        Number.Integer:            "",        # class: 'mi'
        Number.Integer.Long:       "",        # class: 'il'
        Number.Oct:                "",        # class: 'mo'

        Literal:                   "", # class: 'l'
        Literal.Date:              "", # class: 'ld'

        String:                    YELLOW, # class: 's'
        String.Backtick:           YELLOW,        # class: 'sb'
        String.Char:               YELLOW,        # class: 'sc'
        String.Doc:                "",        # class: 'sd' - like a comment
        String.Double:             "",        # class: 's2'
        String.Escape:             "", # class: 'se'
        String.Heredoc:            "",        # class: 'sh'
        String.Interpol:           "",        # class: 'si'
        String.Other:              "",        # class: 'sx'
        String.Regex:              "",        # class: 'sr'
        String.Single:             "",        # class: 's1'
        String.Symbol:             "",        # class: 'ss'

        Generic:                   "",        # class: 'g'
        Generic.Deleted:           "", # class: 'gd',
        Generic.Emph:              "italic",  # class: 'ge'
        Generic.Error:             "",        # class: 'gr'
        Generic.Heading:           "",        # class: 'gh'
        Generic.Inserted:          "", # class: 'gi'
        Generic.Output:            "",        # class: 'go'
        Generic.Prompt:            "",        # class: 'gp'
        Generic.Strong:            "bold",    # class: 'gs'
        Generic.Subheading:        "", # class: 'gu'
        Generic.Traceback:         "",        # class: 'gt'
    }