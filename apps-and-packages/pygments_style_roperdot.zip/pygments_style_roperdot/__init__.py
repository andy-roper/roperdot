#import roperdot
#RoperdotStyle = roperdot.RoperdotStyle

#from roperdot import RoperdotStyle

#from . import roperdot
#class RoperdotStyle(object):
#		pass

version = '1.0'