"""
roperdot Pygments style
"""

try:
	from setuptools import setup, find_packages
except ImportError:
	from distutils.core import setup

setup(
    name         = 'roperdot',
    version      = '1.0',
    description  = 'roperdot is a style for Pygments.',
    author       = 'Andy Roper',
    install_requires = ['pygments'],
#    packages     = find_packages(),
	packages     = ['pygments_style_roperdot'],
#	package_dir={'pygments_style_roperdot': 'pygments_style_roperdot'},
    entry_points = '''
    [pygments.styles]
    roperdot=pygments_style_roperdot.roperdot:RoperdotStyle
    ''',
    zip_safe=False
)
